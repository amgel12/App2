const CACHE_NAME = "musica-v1";
const archivosACachear = [
  "index.html",
  "manifest.json",
  "icono.png",
  "musica/micancion.mp3"
];

self.addEventListener("install", e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(archivosACachear))
  );
});

self.addEventListener("fetch", e => {
  e.respondWith(
    caches.match(e.request).then(respuesta => {
      return respuesta || fetch(e.request);
    })
  );
});
